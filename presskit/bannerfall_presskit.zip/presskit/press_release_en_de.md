# Pressemitteilung (DE für österreichische/deutsche Presse, EN für Mobile-Spieleseiten)

Vor dem Versand: [DATUM] eintragen. Den Absatz mit [OPTIONAL KI] nur drinlassen, wenn du die KI-Hilfe offen erzählen
willst – für Regionalpresse ist das oft der interessanteste Aufhänger, du musst es aber nicht. Alles andere ist im
Spiel belegt.

---

## Deutsch

**Betreff (Mail):** Steirischer Solo-Entwickler bringt Strategiespiel „Bannerfall“ in den App Store

**Hausmannstätten, [DATUM]** – Jakob Ehmann aus Hausmannstätten bei Graz hat allein ein Handyspiel entwickelt: „Bannerfall: Tiny Battle“ ist ab heute kostenlos im App Store für iPhone und iPad erhältlich. Die Android-Version läuft bereits im offenen Test bei Google Play und soll in Kürze folgen.

In Bannerfall stellen Spielerinnen und Spieler eine Armee aus Rittern, Bogenschützen, Magiern und Samurai zusammen, lassen Feuer vom Himmel regnen und stürmen die gegnerische Burg, bevor die eigene fällt. Jeder Kampf verläuft anders, weil man bei jedem Stufenaufstieg aus drei Karten wählt. Zwischen den Kämpfen werden 22 Einheiten gesammelt und weiterentwickelt, Ausrüstung geschmiedet und ein Raid mit acht Bossen bestritten.

„Ich wollte ein Spiel machen, das man fair spielen kann“, sagt Ehmann. „Die ganze Kampagne ist kostenlos, es gibt kein Energiesystem, das einen nach ein paar Runden stoppt, und Werbevideos laufen nur, wenn man selbst eines anschaut.“

Begonnen hat Ehmann Ende September 2026, rund sechs Wochen später ist das Spiel nach einem öffentlichen Betatest erschienen. Entwickelt wurde es mit der freien Spiele-Engine Godot.

[OPTIONAL KI] Möglich war das Tempo auch durch KI: Ehmann hat beim Programmieren, Testen und Ausbalancieren mit einem KI-Assistenten gearbeitet, der etwa tausende Testkämpfe automatisch durchspielte. Die Grafik basiert auf lizenzierten Zeichnungen, die für das Spiel angepasst wurden.

Zum Start gibt es eine „Launch Week“: ein Geschenk für alle, ein Gemeinschaftsziel, bei dem alle zusammen 200.000 Gegner besiegen, und ein Turnier mit Preisen. Wer vor dem 26. November startet, wird dauerhaft „Founder“ und bekommt ein goldenes Banner für seine Burg.

**Infos und Bilder:** https://bannerfall-tinybattle.com/de/presskit.html
**App Store:** https://apps.apple.com/app/id6824882107
**Kontakt:** Jakob Ehmann, ehmannjakob@gmail.com

---

## English

**Subject:** Solo dev from Austria launches lane battle strategy game Bannerfall on iOS

**[DATE]** – Bannerfall: Tiny Battle, a cute but tactical lane battle game made by solo developer Jakob Ehmann from Austria, is out now for free on iPhone and iPad. The Android version is in open testing on Google Play and launches soon.

Players build an army of knights, archers, mages and samurai, rain fire on the enemy and storm the enemy castle before their own falls. Every level-up in battle offers a choice of three cards – new units, upgrades, abilities or spells – so no two battles play the same. Between battles, players collect and ascend 22 units (each transforms twice), forge gear with elemental effects, choose talent paths and take on a raid with eight bosses.

"I wanted a game you can play fairly," says Ehmann. "The whole campaign is free, there's no energy system stopping you after a few rounds, and reward videos only play when you choose one."

The game launches with a Launch Week: a gift for every player, a community goal to defeat 200,000 enemies together, and a tournament with prizes. Everyone who starts before November 26 becomes a permanent Founder with a golden banner on their castle.

**Press kit:** https://bannerfall-tinybattle.com/presskit.html
**App Store:** https://apps.apple.com/app/id6824882107
**Contact:** Jakob Ehmann, ehmannjakob@gmail.com

---

## Kurze Begleitmail (für Redaktionen, über dem Text einfügen)

**DE:** Hallo [Name/Redaktion], ich bin Solo-Entwickler aus Hausmannstätten und habe heute mein erstes Handyspiel veröffentlicht. Unten die Pressemitteilung, Bilder und ein kurzer Trailer liegen im Pressebereich. Für Fragen oder ein kurzes Gespräch bin ich gern erreichbar. Viele Grüße, Jakob Ehmann

**EN:** Hi [name], I'm a solo developer from Austria and my lane battle strategy game Bannerfall just launched on iOS. Press release below; screenshots, logo and a short trailer are in the press kit. Happy to answer questions or provide promo codes for in-game gems if useful. Best, Jakob Ehmann

(Hinweis: „promo codes for in-game gems“ nur drinlassen, wenn du ihnen auf Nachfrage per Postfach-Geschenk Edelsteine schicken willst – das geht über die Admin-Webseite an ihre Spieler-ID.)
